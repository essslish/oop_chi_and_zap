﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Xml.Linq;

namespace CityDirectory
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                Console.WriteLine("Введите путь до файла-справочника или команду для завершения работы:");
                string input = Console.ReadLine();

                if (input.Equals("exit", StringComparison.OrdinalIgnoreCase))
                {
                    break;
                }

                if (File.Exists(input))
                {
                    var stopwatch = new Stopwatch();
                    stopwatch.Start();

                    if (input.EndsWith(".xml"))
                    {
                        ProcessXmlFile(input);
                    }
                    else if (input.EndsWith(".csv"))
                    {
                        ProcessCsvFile(input);
                    }
                    else
                    {
                        Console.WriteLine("Неподдерживаемый формат файла.");
                    }

                    stopwatch.Stop();
                    Console.WriteLine($"Время обработки файла: {stopwatch.ElapsedMilliseconds} мс");
                }
                else
                {
                    Console.WriteLine("Файл не найден.");
                }
            }
        }

        private static void ProcessXmlFile(string filePath)
        {
            try
            {
                XDocument doc = XDocument.Load(filePath);
                var addresses = doc.Descendants("item")
                                   .Select(x => new Address
                                   {
                                       City = x.Attribute("city")?.Value.Trim(),
                                       Floors = int.Parse(x.Attribute("floor")?.Value.Trim() ?? "0")
                                   }).ToList();

                DisplayStatistics(addresses);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при обработке XML файла: {ex.Message}");
            }
        }

        private static void ProcessCsvFile(string filePath)
        {
            try
            {
                var addresses = File.ReadAllLines(filePath)
                                    .Skip(1)
                                    .Select(line => line.Split(','))
                                    .Select(parts => new Address
                                    {
                                        City = parts[0].Trim(),
                                        Floors = int.Parse(parts[1].Trim())
                                    }).ToList();

                DisplayStatistics(addresses);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при обработке CSV файла: {ex.Message}");
            }
        }

        private static void DisplayStatistics(List<Address> addresses)
        {
            var duplicates = addresses.GroupBy(a => new { a.City, a.Floors })
                                      .Where(g => g.Count() > 1)
                                      .Select(g => new { Address = g.Key, Count = g.Count() });

            Console.WriteLine("Дублирующиеся записи:");
            foreach (var duplicate in duplicates)
            {
                Console.WriteLine($"{duplicate.Address.City}, {duplicate.Address.Floors} этажей - {duplicate.Count} раз");
            }

            var cityStatistics = addresses.GroupBy(a => a.City)
                                          .Select(g => new
                                          {
                                              City = g.Key,
                                              Stats = g.GroupBy(a => a.Floors)
                                                       .Select(fg => new { Floors = fg.Key, Count = fg.Count() })
                                          });

            Console.WriteLine("Количество зданий по этажам в каждом городе:");
            foreach (var cityStat in cityStatistics)
            {
                Console.WriteLine(cityStat.City);
                foreach (var stat in cityStat.Stats)
                {
                    Console.WriteLine($"{stat.Floors} этажей: {stat.Count}");
                }
            }
        }
    }

    public class Address
    {
        public string City { get; set; }
        public int Floors { get; set; }
    }
}
//using System;
//using System.Collections.Generic;
//using System.Diagnostics;
//using System.IO;
//using System.Linq;
//using System.Net;
//using System.Xml.Linq;

//namespace CityDirectory
//{
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            while (true)
//            {
//                Console.WriteLine("Введите путь до файла-справочника или команду для завершения работы:");
//                string input = Console.ReadLine();

//                if (input.Equals("exit", StringComparison.OrdinalIgnoreCase))
//                {
//                    break;
//                }

//                if (File.Exists(input))
//                {
//                    var stopwatch = new Stopwatch();
//                    stopwatch.Start();

//                    if (input.EndsWith(".xml"))
//                    {
//                        ProcessXmlFile(input);
//                    }
//                    else if (input.EndsWith(".csv"))
//                    {
//                        ProcessCsvFile(input);
//                    }
//                    else
//                    {
//                        Console.WriteLine("Неподдерживаемый формат файла.");
//                    }

//                    stopwatch.Stop();
//                    Console.WriteLine($"Время обработки файла: {stopwatch.ElapsedMilliseconds} мс");
//                }
//                else
//                {
//                    Console.WriteLine("Файл не найден.");
//                }
//            }
//        }

//        private static void ProcessXmlFile(string filePath)
//        {
//            try
//            {
//                XDocument doc = XDocument.Load(filePath);
//                var addresses = doc.Descendants("item")
//                                   .Select(x => new Address
//                                   {
//                                       City = x.Attribute("city")?.Value.Trim(),
//                                       Street = x.Attribute("street")?.Value.Trim(),
//                                       House = x.Attribute("house")?.Value.Trim(),
//                                       Floor = int.Parse(x.Attribute("floor")?.Value.Trim() ?? "0")
//                                   }).ToList();

//                DisplayStatistics(addresses);
//            }
//            catch (Exception ex)
//            {
//                Console.WriteLine($"Ошибка при обработке XML файла: {ex.Message}");
//            }
//        }

//        private static void ProcessCsvFile(string filePath)
//        {
//            try
//            {
//                var addresses = File.ReadAllLines(filePath)
//                                    .Skip(1)
//                                    .Select(line => line.Split('\t')) // Используем табуляцию как разделитель
//                                    .Where(parts => parts.Length == 4) // Добавляем проверку на количество элементов
//                                    .Select(parts => new Address
//                                    {
//                                        City = parts[0].Trim(),
//                                        Street = parts[1].Trim(),
//                                        House = parts[2].Trim(),
//                                        Floor = int.Parse(parts[3].Trim())
//                                    }).ToList();

//                DisplayStatistics(addresses);
//            }
//            catch (Exception ex)
//            {
//                Console.WriteLine($"Ошибка при обработке CSV файла: {ex.Message}");
//            }
//        }

//        private static void DisplayStatistics(List<Address> addresses)
//        {
//            var duplicates = addresses.GroupBy(a => new { a.City, a.Street, a.House, a.Floor })
//                                      .Where(g => g.Count() > 1)
//                                      .Select(g => new { Address = g.Key, Count = g.Count() });

//            Console.WriteLine("Дублирующиеся записи:");
//            foreach (var duplicate in duplicates)
//            {
//                Console.WriteLine($"{duplicate.Address.City}, {duplicate.Address.Street}, {duplicate.Address.House}, {duplicate.Address.Floor} этажей - {duplicate.Count} раз");
//            }

//            var cityStatistics = addresses.GroupBy(a => a.City)
//                                          .Select(g => new
//                                          {
//                                              City = g.Key,
//                                              Stats = g.GroupBy(a => a.Floor)
//                                                       .Select(fg => new { Floors = fg.Key, Count = fg.Count() })
//                                          });

//            Console.WriteLine("Количество зданий по этажам в каждом городе:");
//            foreach (var cityStat in cityStatistics)
//            {
//                Console.WriteLine(cityStat.City);
//                foreach (var stat in cityStat.Stats)
//                {
//                    Console.WriteLine($"{stat.Floors} этажей: {stat.Count}");
//                }
//            }
//        }
//    }

//    public class Address
//    {
//        public string City { get; set; }
//        public string Street { get; set; }
//        public string House { get; set; }
//        public int Floor { get; set; }
//    }
//}

/* 
 using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Linq;

namespace XmlToCsvConverter
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите путь до XML файла:");
            string xmlFilePath = Console.ReadLine();

            if (!File.Exists(xmlFilePath))
            {
                Console.WriteLine("XML файл не найден.");
                return;
            }

            Console.WriteLine("Введите путь до CSV файла для сохранения:");
            string csvFilePath = Console.ReadLine();

            try
            {
                // Читаем данные из XML файла и преобразуем их в объекты Address
                var addresses = LoadAddressesFromXml(xmlFilePath);

                // Записываем данные в CSV файл
                SaveAddressesToCsv(addresses, csvFilePath);

                Console.WriteLine("Данные успешно перенесены из XML в CSV файл.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при перенесении данных: {ex.Message}");
            }
        }

        // Метод для чтения данных из XML файла
        private static List<Address> LoadAddressesFromXml(string filePath)
        {
            XDocument doc = XDocument.Load(filePath);
            var addresses = doc.Descendants("item")
                               .Select(x => new Address
                               {
                                   City = x.Attribute("city")?.Value.Trim(),
                                   Street = x.Attribute("street")?.Value.Trim(),
                                   House = x.Attribute("house")?.Value.Trim(),
                                   Floor = x.Attribute("floor")?.Value.Trim()
                               }).ToList();

            return addresses;
        }

        // Метод для записи данных в CSV файл
        private static void SaveAddressesToCsv(List<Address> addresses, string filePath)
        {
            using (var writer = new StreamWriter(filePath, false, Encoding.UTF8))
            {
                // Записываем заголовок колонок
                writer.WriteLine("city;street;house;floor");

                // Записываем данные
                foreach (var address in addresses)
                {
                    writer.WriteLine($"{address.City};{address.Street};{address.House};{address.Floor}");
                }
            }
        }
    }

    // Класс для представления адреса
    public class Address
    {
        public string City { get; set; }
        public string Street { get; set; }
        public string House { get; set; }
        public string Floor { get; set; }
    }
}
 */